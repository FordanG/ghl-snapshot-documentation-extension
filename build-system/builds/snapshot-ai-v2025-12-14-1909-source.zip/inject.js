// This script runs in the page context to access GHL's Nuxt app data and auth token
(function() {
  console.log('[Inject.js] Script running in page context');

  let pageData = {};
  let hasGHLData = false;
  let authToken = null;
  let locationId = null;

  // Try Nuxt 3 (most reliable for GHL pages)
  try {
    if (typeof useNuxtApp === 'function') {
      const nuxtApp = useNuxtApp();
      pageData = nuxtApp?.payload?.data?.pageData || {};
      if (pageData && (pageData.pageId || pageData.funnelId || pageData.stepId || pageData.locationId)) {
        hasGHLData = true;
        locationId = pageData.locationId;
        console.log('[Inject.js] Found Nuxt 3 data, locationId:', locationId);
      }
    }
  } catch(e) {
    console.log('[Inject.js] Nuxt 3 not available:', e.message);
  }

  // Try Nuxt 2
  if (!hasGHLData) {
    try {
      if (window.__NUXT__) {
        const nuxtData = window.__NUXT__.data?.[0]?.pageData || window.__NUXT__.pageData || {};
        pageData = {...pageData, ...nuxtData};
        if (pageData && (pageData.pageId || pageData.funnelId || pageData.stepId || pageData.locationId)) {
          hasGHLData = true;
          locationId = pageData.locationId;
          console.log('[Inject.js] Found Nuxt 2 data, locationId:', locationId);
        }
      }
    } catch(e) {
      console.log('[Inject.js] Nuxt 2 not available:', e.message);
    }
  }

  // Extract auth token from localStorage
  try {
    console.log('[Inject.js] Checking localStorage for auth token...');

    // Primary location: localStorage key 'a' contains base64-encoded JSON
    const authDataStr = localStorage.getItem('a');
    console.log('[Inject.js] localStorage.a exists:', !!authDataStr);
    console.log('[Inject.js] localStorage.a length:', authDataStr ? authDataStr.length : 0);

    if (authDataStr) {
      try {
        let authData;

        // localStorage.a is JSON-stringified, so first parse to remove quotes
        let unquotedStr = authDataStr;
        if (authDataStr.startsWith('"') && authDataStr.endsWith('"')) {
          console.log('[Inject.js] Removing JSON quotes from localStorage.a...');
          unquotedStr = JSON.parse(authDataStr);
          console.log('[Inject.js] Unquoted string length:', unquotedStr.length);
        }

        // Check if it's base64-encoded (starts with eyJ which decodes to {)
        if (unquotedStr.startsWith('eyJ')) {
          console.log('[Inject.js] Detected base64-encoded data, decoding...');
          // Decode base64
          const decodedStr = atob(unquotedStr);
          console.log('[Inject.js] Decoded string length:', decodedStr.length);
          console.log('[Inject.js] Decoded preview:', decodedStr.substring(0, 100));
          authData = JSON.parse(decodedStr);
        } else {
          // Try direct JSON parse
          authData = JSON.parse(unquotedStr);
        }

        console.log('[Inject.js] Parsed auth data, keys:', Object.keys(authData));

        // Use authToken (longer RS256 token) which works with snapshot APIs
        // jwt is a shorter HS256 token that doesn't work with all endpoints
        authToken = authData.authToken || authData.jwt;
        if (authToken) {
          // Remove "Bearer " prefix if present
          authToken = authToken.replace(/^Bearer\s+/i, '');
          console.log('[Inject.js] Token found in localStorage.a (using authToken), length:', authToken.length);

          // Store companyId for later use as last resort fallback
          if (authData.companyId) {
            window._ghlAuthCompanyId = authData.companyId;
            console.log('[Inject.js] Company ID found in auth data (will use as last fallback):', authData.companyId);
          }
        } else {
          console.log('[Inject.js] No jwt or authToken field in parsed data');
        }
      } catch(parseError) {
        console.error('[Inject.js] Failed to decode/parse auth data:', parseError);
        console.log('[Inject.js] First 100 chars of authDataStr:', authDataStr.substring(0, 100));
      }
    } else {
      console.log('[Inject.js] localStorage.a is empty/null');
    }

    // Fallback: try legacy auth storage locations
    if (!authToken) {
      console.log('[Inject.js] Trying fallback auth locations...');
      const legacyToken = localStorage.getItem('auth._token.laravelJWT') ||
                         localStorage.getItem('auth.token') ||
                         localStorage.getItem('token') ||
                         localStorage.getItem('jwt');
      if (legacyToken) {
        authToken = legacyToken.replace(/^Bearer\s+/i, '');
        console.log('[Inject.js] Token found in fallback location, length:', authToken.length);
      } else {
        console.log('[Inject.js] No fallback tokens found');
      }
    }
  } catch(e) {
    console.error('[Inject.js] localStorage not accessible:', e);
  }

  // Fallback 1: extract locationId from URL if not found yet
  if (!locationId) {
    const urlMatch = window.location.href.match(/\/location\/([A-Za-z0-9_-]{18,28})/);
    if (urlMatch && urlMatch[1]) {
      locationId = urlMatch[1];
      hasGHLData = true; // URL with /location/ means this is a GHL page
      console.log('[Inject.js] LocationId extracted from URL:', locationId);
    }
  }

  // Fallback 2 (last resort): use companyId from auth data
  if (!locationId && window._ghlAuthCompanyId) {
    locationId = window._ghlAuthCompanyId;
    console.log('[Inject.js] LocationId from auth data companyId (last resort):', locationId);
  }

  // Also check if this is a known GHL domain
  const hostname = window.location.hostname;
  const isGHLDomain = hostname.includes('gohighlevel.com') ||
                      hostname.includes('leadconnectorhq.com') ||
                      hostname.includes('highlevel.com');
  if (isGHLDomain && !hasGHLData) {
    hasGHLData = true;
    console.log('[Inject.js] GHL domain detected:', hostname);
  }

  console.log('[Inject.js] Final state - hasAuth:', !!authToken, 'hasData:', hasGHLData, 'locationId:', locationId);

  // Send data back to content script
  window.postMessage({
    type: 'GHL_PAGE_DATA_RESPONSE',
    data: pageData,
    hasGHLData: hasGHLData,
    authToken: authToken,
    locationId: locationId
  }, '*');

  console.log('[Inject.js] Message posted to content script');

  // Expose Revex service to window for content scripts
  const BASE_URLS = {
    backend: 'https://backend.leadconnectorhq.com',
    services: 'https://services.leadconnectorhq.com'
  };
  const DEFAULT_BASE = 'backend';
  let revexService = null;
  let isRevexReady = false;

  function getRevexService() {
    // Return cached service if available
    if (revexService) {
      return revexService;
    }

    const app = document.querySelector("#app");
    if (!app || !app.__vue_app__) {
      console.log('[Inject.js] Vue app not found yet');
      return null;
    }

    const revex = app.__vue_app__.config.globalProperties.revexBackendService;
    if (!revex) {
      console.log('[Inject.js] revexBackendService not found in Vue app');
      return null;
    }

    console.log('[Inject.js] Revex service found and cached');
    revexService = revex;
    return revex;
  }

  // Wait for Vue app and Revex to be available
  function initializeRevex() {
    console.log('[Inject.js] Starting Revex initialization...');

    let attempts = 0;
    const maxAttempts = 50; // 10 seconds max (50 * 200ms)

    const checkInterval = setInterval(() => {
      attempts++;

      const revex = getRevexService();
      if (revex) {
        clearInterval(checkInterval);
        isRevexReady = true;
        console.log('[Inject.js] Revex initialization complete!');

        // Signal to content script that Revex is ready
        window.postMessage({
          type: 'REVEX_READY',
          success: true
        }, '*');
      } else if (attempts >= maxAttempts) {
        clearInterval(checkInterval);

        // If we have an auth token, we can still work using direct fetch fallback
        if (authToken) {
          isRevexReady = true; // Mark as ready for direct fetch fallback
          console.log('[Inject.js] Vue app not found, but auth token available - using direct fetch fallback');

          window.postMessage({
            type: 'REVEX_READY',
            success: true,
            fallbackMode: true
          }, '*');
        } else {
          console.error('[Inject.js] Revex initialization timeout - Vue app not found and no auth token');

          window.postMessage({
            type: 'REVEX_READY',
            success: false,
            error: 'Vue app not found after timeout and no auth token available'
          }, '*');
        }
      } else {
        console.log(`[Inject.js] Waiting for Vue app... (attempt ${attempts}/${maxAttempts})`);
      }
    }, 200);
  }

  // Create a message-based API bridge
  window.addEventListener('message', async (event) => {
    if (event.source !== window) return;

    const { type, endpoint, data: reqData, requestId, baseUrl } = event.data;

    // Handle readiness check requests
    if (type === 'REVEX_CHECK_READY') {
      window.postMessage({
        type: 'REVEX_READY',
        success: isRevexReady
      }, '*');
      return;
    }

    // Handle API requests
    if (!type || !type.startsWith('REVEX_')) return;
    if (type === 'REVEX_READY' || type === 'REVEX_RESPONSE') return;

    try {
      const revex = getRevexService();
      const useDirectFetch = !revex && authToken;

      if (!isRevexReady && !useDirectFetch) {
        throw new Error('Revex service not initialized and no auth token available');
      }

      if (!revex && !authToken) {
        throw new Error('Revex service not available and no auth token for fallback');
      }

      // Log which method we're using
      if (useDirectFetch) {
        console.log('[Inject.js] Using direct fetch fallback (Revex not available)');
      }

      let response;

      // Handle REVEX_FETCH - flexible fetch with custom URLs and any HTTP method
      if (type === 'REVEX_FETCH') {
        console.log('[Inject.js] REVEX_FETCH request:', reqData?.method || 'GET', endpoint);

        if (!authToken) {
          throw new Error('Auth token not available for fetch request');
        }

        const method = reqData?.method || 'GET';
        const customHeaders = reqData?.headers || {};

        // Build headers with auth token
        const headers = {
          'Authorization': `Bearer ${authToken}`,
          'channel': 'APP',
          'source': 'WEB_USER',
          'version': '2021-07-28',
          'Content-Type': 'application/json',
          'Accept': 'application/json',
          ...customHeaders
        };

        // Build fetch options
        const fetchOptions = {
          method: method,
          headers: headers,
          credentials: 'omit'
        };

        // Add body for methods that support it
        if (reqData?.body && !['GET', 'HEAD'].includes(method)) {
          fetchOptions.body = typeof reqData.body === 'string'
            ? reqData.body
            : JSON.stringify(reqData.body);
        }

        console.log('[Inject.js] Fetch options:', { method, url: endpoint });

        const fetchResponse = await fetch(endpoint, fetchOptions);

        if (!fetchResponse.ok) {
          throw new Error(`HTTP ${fetchResponse.status}: ${fetchResponse.statusText}`);
        }

        const data = await fetchResponse.json();
        response = { data, status: fetchResponse.status };

        window.postMessage({
          type: 'REVEX_RESPONSE',
          requestId,
          success: true,
          data: response.data,
          status: response.status
        }, '*');
        return;
      }

      // Determine which base URL to use
      const selectedBase = baseUrl && BASE_URLS[baseUrl] ? BASE_URLS[baseUrl] : BASE_URLS[DEFAULT_BASE];
      const fullUrl = selectedBase + endpoint;

      console.log('[Inject.js] Using base URL:', selectedBase, 'for endpoint:', endpoint);

      // For snapshot-appengine endpoints, use direct fetch with Bearer token
      const needsDirectFetch = endpoint.includes('/snapshots-appengine/');
      const needsBearerAuth = endpoint.includes('/snapshots/');

      if (needsDirectFetch && authToken) {
        console.log('[Inject.js] Using direct fetch for snapshot-appengine with Bearer auth');

        const headers = {
          'Authorization': `Bearer ${authToken}`,
          'channel': 'APP',
          'source': 'WEB_USER',
          'version': '2021-07-28',
          'Content-Type': 'application/json',
          'Accept': 'application/json'
        };

        let fetchResponse;
        switch (type) {
          case 'REVEX_GET':
            fetchResponse = await fetch(fullUrl, {
              method: 'GET',
              headers: headers,
              credentials: 'omit'
            });
            break;
          case 'REVEX_POST':
            fetchResponse = await fetch(fullUrl, {
              method: 'POST',
              headers: headers,
              body: JSON.stringify(reqData),
              credentials: 'omit'
            });
            break;
          case 'REVEX_PUT':
            fetchResponse = await fetch(fullUrl, {
              method: 'PUT',
              headers: headers,
              body: JSON.stringify(reqData),
              credentials: 'omit'
            });
            break;
          default:
            throw new Error('Unknown request type');
        }

        if (!fetchResponse.ok) {
          throw new Error(`HTTP ${fetchResponse.status}: ${fetchResponse.statusText}`);
        }

        const data = await fetchResponse.json();
        response = { data, status: fetchResponse.status };

      } else if (needsBearerAuth && authToken) {
        console.log('[Inject.js] Adding Bearer token and required headers for snapshot API');
        const config = {
          headers: {
            'Authorization': `Bearer ${authToken}`,
            'channel': 'APP',
            'source': 'WEB_USER',
            'version': '2021-07-28'
          }
        };

        switch (type) {
          case 'REVEX_GET':
            response = await revex.get(fullUrl, config);
            break;
          case 'REVEX_POST':
            response = await revex.post(fullUrl, reqData, config);
            break;
          case 'REVEX_PUT':
            response = await revex.put(fullUrl, reqData, config);
            break;
          default:
            throw new Error('Unknown request type');
        }
      } else if (useDirectFetch) {
        // Fallback: Use direct fetch with auth token when Revex isn't available (whitelabeled domains)
        console.log('[Inject.js] Using direct fetch fallback for:', fullUrl);

        const headers = {
          'Authorization': `Bearer ${authToken}`,
          'channel': 'APP',
          'source': 'WEB_USER',
          'version': '2021-07-28',
          'Content-Type': 'application/json',
          'Accept': 'application/json'
        };

        let fetchResponse;
        switch (type) {
          case 'REVEX_GET':
            fetchResponse = await fetch(fullUrl, {
              method: 'GET',
              headers: headers,
              credentials: 'omit'
            });
            break;
          case 'REVEX_POST':
            fetchResponse = await fetch(fullUrl, {
              method: 'POST',
              headers: headers,
              body: JSON.stringify(reqData),
              credentials: 'omit'
            });
            break;
          case 'REVEX_PUT':
            fetchResponse = await fetch(fullUrl, {
              method: 'PUT',
              headers: headers,
              body: JSON.stringify(reqData),
              credentials: 'omit'
            });
            break;
          default:
            throw new Error('Unknown request type');
        }

        if (!fetchResponse.ok) {
          throw new Error(`HTTP ${fetchResponse.status}: ${fetchResponse.statusText}`);
        }

        const data = await fetchResponse.json();
        response = { data, status: fetchResponse.status };

      } else {
        // Use standard Revex authentication for other endpoints
        switch (type) {
          case 'REVEX_GET':
            response = await revex.get(fullUrl);
            break;
          case 'REVEX_POST':
            response = await revex.post(fullUrl, reqData);
            break;
          case 'REVEX_PUT':
            response = await revex.put(fullUrl, reqData);
            break;
          default:
            throw new Error('Unknown request type');
        }
      }

      window.postMessage({
        type: 'REVEX_RESPONSE',
        requestId,
        success: true,
        data: response.data,
        status: response.status
      }, '*');
    } catch (error) {
      console.error('[Inject.js] Revex API error:', error);
      window.postMessage({
        type: 'REVEX_RESPONSE',
        requestId,
        success: false,
        error: error.message || 'Unknown error'
      }, '*');
    }
  });

  console.log('[Inject.js] Revex message bridge ready, starting initialization...');

  // Start initialization when DOM is ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initializeRevex);
  } else {
    // DOM already loaded, start immediately
    setTimeout(initializeRevex, 100);
  }
})();
