/**
 * GHL Snapshot Export - Background Service Worker
 */

console.log('[Background] GHL Snapshot Export extension loaded');

// Listen for extension installation or updates
chrome.runtime.onInstalled.addListener((details) => {
  if (details.reason === 'install') {
    console.log('[Background] Extension installed');
  } else if (details.reason === 'update') {
    console.log('[Background] Extension updated to version', chrome.runtime.getManifest().version);
  }
});

// Handle messages from content scripts and popup
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  console.log('[Background] Message received:', request.action || request);

  // Handle OpenAI API calls from content scripts
  // Background script has unrestricted fetch access, unlike content scripts on some domains
  if (request.action === 'callOpenAI') {
    console.log('[Background] OpenAI API call requested');

    (async () => {
      try {
        const response = await fetch('https://api.openai.com/v1/chat/completions', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${request.apiKey}`
          },
          body: JSON.stringify({
            model: request.model || 'gpt-4o-mini',
            messages: request.messages,
            temperature: request.temperature || 0.7,
            max_tokens: request.maxTokens || 500
          })
        });

        if (!response.ok) {
          const errorData = await response.json().catch(() => ({}));
          const errorMsg = errorData.error?.message || response.statusText;
          console.error('[Background] OpenAI API error:', response.status, errorMsg);
          sendResponse({
            success: false,
            error: `OpenAI API error (${response.status}): ${errorMsg}`
          });
          return;
        }

        const data = await response.json();
        console.log('[Background] OpenAI API success');
        sendResponse({ success: true, data: data });
      } catch (error) {
        console.error('[Background] OpenAI fetch error:', error);
        sendResponse({ success: false, error: error.message });
      }
    })();

    return true; // Keep the message channel open for async response
  }

  // Forward progress updates to popup and persist to storage
  if (request.action === 'snapshotExportProgress') {
    // Store progress in chrome.storage so popup can restore it
    const isComplete = request.progress >= 100;
    const isError = request.progress === 0 && request.message && request.message.startsWith('Error:');
    chrome.storage.local.set({
      snapshotExportState: {
        isExporting: !isComplete && !isError,
        progress: request.progress,
        message: request.message,
        timestamp: Date.now()
      }
    });

    // Clear export state after completion or error (with small delay)
    if (isComplete || isError) {
      setTimeout(() => {
        chrome.storage.local.set({
          snapshotExportState: { isExporting: false, progress: 0, message: '' }
        });
      }, 3000);
    }

    // Broadcast to all extension views (popup)
    chrome.runtime.sendMessage(request).catch(() => {
      // Popup might be closed, that's ok - state is persisted
    });
  }

  // Forward location export progress and persist to storage
  if (request.action === 'locationExportProgress') {
    const isComplete = request.progress >= 100;
    const isError = request.progress === 0 && request.message && request.message.startsWith('Error:');
    chrome.storage.local.set({
      locationExportState: {
        isExporting: !isComplete && !isError,
        progress: request.progress,
        message: request.message,
        timestamp: Date.now()
      }
    });

    // Clear export state after completion or error (with small delay)
    if (isComplete || isError) {
      setTimeout(() => {
        chrome.storage.local.set({
          locationExportState: { isExporting: false, progress: 0, message: '' }
        });
      }, 3000);
    }

    // Broadcast to all extension views (popup)
    chrome.runtime.sendMessage(request).catch(() => {
      // Popup might be closed, that's ok - state is persisted
    });
  }

  return false;
});
