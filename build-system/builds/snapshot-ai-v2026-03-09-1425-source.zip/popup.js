/**
 * GHL Snapshot Export - Popup UI Controller (v1)
 */

// DOM elements
const exportFormatSelect = document.getElementById('exportFormat');
const openaiKeyInput = document.getElementById('openaiKey');
const enableAICheckbox = document.getElementById('enableAI');
const selectAllAssetsButton = document.getElementById('selectAllAssets');
const deselectAllAssetsButton = document.getElementById('deselectAllAssets');

// Location export DOM elements
const exportLocationButton = document.getElementById('exportLocationButton');
const currentLocationIdInput = document.getElementById('currentLocationId');
const locationProgress = document.getElementById('locationProgress');
const locationProgressText = document.getElementById('locationProgressText');
const locationProgressBar = document.getElementById('locationProgressBar');
const locationMessageDiv = document.getElementById('locationMessage');

// License DOM elements
const licenseCodeInput = document.getElementById('licenseCode');
const activateLicenseBtn = document.getElementById('activateLicenseBtn');
const deactivateLicenseBtn = document.getElementById('deactivateLicenseBtn');
const licenseStatusContainer = document.getElementById('licenseStatusContainer');
const licenseInputContainer = document.getElementById('licenseInputContainer');
const licenseUsageInfo = document.getElementById('licenseUsageInfo');
const licenseMessage = document.getElementById('licenseMessage');

// OpenAI key UI elements
const openaiKeyInputContainer = document.getElementById('openaiKeyInputContainer');
const openaiKeySavedContainer = document.getElementById('openaiKeySavedContainer');
const openaiKeyMasked = document.getElementById('openaiKeyMasked');
const testOpenaiKeyBtn = document.getElementById('testOpenaiKey');
const changeOpenaiKeyBtn = document.getElementById('changeOpenaiKey');
const openaiKeyStatus = document.getElementById('openaiKeyStatus');
const includeFullEnrichmentCheckbox = document.getElementById('includeFullEnrichment');

// Export overlay DOM elements
const exportOverlay = document.getElementById('exportOverlay');
const exportOverlayType = document.getElementById('exportOverlayType');
const exportOverlayStatus = document.getElementById('exportOverlayStatus');
const exportOverlayBar = document.getElementById('exportOverlayBar');
const exportOverlayPercent = document.getElementById('exportOverlayPercent');
const dismissOverlayBtn = document.getElementById('dismissOverlayBtn');

let isLicenseValid = false;
let isExportRunning = false;

// Load saved settings
chrome.storage.local.get(['openaiApiKey', 'aiAnalysisEnabled', 'includeFullEnrichment'], (result) => {
  console.log('[Popup] Loading AI settings:', { hasKey: !!result.openaiApiKey, aiEnabled: result.aiAnalysisEnabled, includeFullEnrichment: result.includeFullEnrichment });

  if (result.openaiApiKey) {
    showSavedKeyUI(result.openaiApiKey);
  } else {
    showKeyInputUI();
  }

  enableAICheckbox.checked = result.aiAnalysisEnabled === true;
  includeFullEnrichmentCheckbox.checked = result.includeFullEnrichment !== false;
});

// Show the saved key indicator UI
function showSavedKeyUI(key) {
  openaiKeyInputContainer.style.display = 'none';
  openaiKeySavedContainer.style.display = 'block';
  openaiKeyStatus.style.display = 'none';
  const maskedKey = key.substring(0, 7) + '...' + key.substring(key.length - 4);
  openaiKeyMasked.textContent = `API Key: ${maskedKey}`;
}

// Show the key input UI
function showKeyInputUI() {
  openaiKeyInputContainer.style.display = 'flex';
  openaiKeySavedContainer.style.display = 'none';
  openaiKeyInput.value = '';
}

// Change key button
changeOpenaiKeyBtn.addEventListener('click', () => {
  chrome.storage.local.get(['openaiApiKey'], (result) => {
    showKeyInputUI();
    if (result.openaiApiKey) {
      openaiKeyInput.value = result.openaiApiKey;
    }
  });
});

// Test OpenAI key button
testOpenaiKeyBtn.addEventListener('click', async () => {
  const key = openaiKeyInput.value.trim();

  if (!key) {
    showKeyStatus('Please enter an API key first', 'error');
    return;
  }

  if (!key.startsWith('sk-')) {
    showKeyStatus('Invalid key format - should start with sk-', 'error');
    return;
  }

  testOpenaiKeyBtn.disabled = true;
  testOpenaiKeyBtn.textContent = 'Testing...';
  showKeyStatus('Testing connection...', 'info');

  try {
    const response = await fetch('https://api.openai.com/v1/models', {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${key}`
      }
    });

    if (response.ok) {
      showKeyStatus('API key is valid and working!', 'success');
      chrome.storage.local.set({ openaiApiKey: key }, () => {
        console.log('[Popup] OpenAI key saved after successful test');
        setTimeout(() => {
          showSavedKeyUI(key);
        }, 1500);
      });
    } else {
      const error = await response.json().catch(() => ({}));
      showKeyStatus(`Invalid key: ${error.error?.message || response.statusText}`, 'error');
    }
  } catch (error) {
    showKeyStatus(`Connection error: ${error.message}`, 'error');
  } finally {
    testOpenaiKeyBtn.disabled = false;
    testOpenaiKeyBtn.textContent = 'Test';
  }
});

// Show status message for OpenAI key
function showKeyStatus(message, type) {
  openaiKeyStatus.style.display = 'block';
  openaiKeyStatus.textContent = message;

  if (type === 'success') {
    openaiKeyStatus.style.background = '#f0fdf4';
    openaiKeyStatus.style.color = '#166534';
    openaiKeyStatus.style.border = '1px solid #bbf7d0';
  } else if (type === 'error') {
    openaiKeyStatus.style.background = '#fef2f2';
    openaiKeyStatus.style.color = '#991b1b';
    openaiKeyStatus.style.border = '1px solid #fecaca';
  } else {
    openaiKeyStatus.style.background = '#eff6ff';
    openaiKeyStatus.style.color = '#1e40af';
    openaiKeyStatus.style.border = '1px solid #bfdbfe';
  }
}

// Save AI enabled setting when it changes
enableAICheckbox.addEventListener('change', () => {
  chrome.storage.local.set({ aiAnalysisEnabled: enableAICheckbox.checked }, () => {
    console.log('[Popup] AI analysis enabled:', enableAICheckbox.checked);
  });
});

// Save includeFullEnrichment setting when it changes
includeFullEnrichmentCheckbox.addEventListener('change', () => {
  chrome.storage.local.set({ includeFullEnrichment: includeFullEnrichmentCheckbox.checked }, () => {
    console.log('[Popup] Include full enrichment:', includeFullEnrichmentCheckbox.checked);
  });
});

/**
 * Show the export overlay
 */
function showExportOverlay() {
  isExportRunning = true;
  exportOverlay.classList.add('active');
  exportOverlayType.textContent = 'Exporting location assets...';
  exportOverlayStatus.textContent = 'Preparing export...';
  exportOverlayBar.style.width = '0%';
  exportOverlayPercent.textContent = '0%';
  console.log('[Popup] Export overlay shown');
  startExportMonitor();
}

/**
 * Update the export overlay progress
 */
function updateExportOverlay(progress, message) {
  exportOverlayStatus.textContent = message;
  exportOverlayBar.style.width = progress + '%';
  exportOverlayPercent.textContent = Math.round(progress) + '%';
}

/**
 * Hide the export overlay
 */
function hideExportOverlay() {
  isExportRunning = false;
  exportOverlay.classList.remove('active');
  stopExportMonitor();
  console.log('[Popup] Export overlay hidden');
}

/**
 * Dismiss overlay button handler
 */
dismissOverlayBtn.addEventListener('click', () => {
  console.log('[Popup] User dismissed export overlay');
  hideExportOverlay();
  chrome.storage.local.set({
    locationExportState: { isExporting: false, progress: 0, message: '' }
  });
  exportLocationButton.disabled = false;
});

/**
 * Check if an export is already running
 */
function canStartExport() {
  if (isExportRunning) {
    alert('An export is already in progress. Please wait for it to complete.');
    return false;
  }
  return true;
}

/**
 * Restore export progress state when popup opens
 */
async function restoreExportProgress() {
  try {
    const result = await chrome.storage.local.get(['locationExportState']);

    if (result.locationExportState && result.locationExportState.isExporting) {
      const state = result.locationExportState;
      if (state.progress === 0 && state.message && state.message.startsWith('Error:')) {
        console.log('[Popup] Skipping restore - location export errored:', state.message);
        chrome.storage.local.set({ locationExportState: { isExporting: false, progress: 0, message: '' } });
        return;
      }
      if (Date.now() - state.timestamp < 10 * 60 * 1000) {
        console.log('[Popup] Restoring location export progress:', state);
        isExportRunning = true;
        exportOverlay.classList.add('active');
        exportOverlayType.textContent = 'Exporting location assets...';
        updateExportOverlay(state.progress, state.message || 'Export in progress...');
        startExportMonitor();
      } else {
        console.log('[Popup] Clearing stale location export state');
        chrome.storage.local.set({ locationExportState: { isExporting: false, progress: 0, message: '' } });
      }
    }
  } catch (error) {
    console.error('[Popup] Error restoring export progress:', error);
  }
}

restoreExportProgress();

/**
 * License Management
 */

async function initializeLicense() {
  try {
    const result = await window.licenseManager.checkStoredLicense();
    if (result.valid) {
      showLicenseActive(result);
    } else {
      showLicenseInput();
    }
  } catch (error) {
    console.error('[Popup] License init error:', error);
    showLicenseInput();
  }
}

function showLicenseActive(result) {
  isLicenseValid = true;
  licenseStatusContainer.style.display = 'block';
  licenseInputContainer.style.display = 'none';

  const usageText = result.remainingUses === 'unlimited'
    ? `${result.usageCount || 0} exports used`
    : `${result.usageCount || 0} / ${result.license.max_uses} exports used`;
  licenseUsageInfo.textContent = usageText;

  exportLocationButton.disabled = false;
}

function showLicenseInput() {
  isLicenseValid = false;
  licenseStatusContainer.style.display = 'none';
  licenseInputContainer.style.display = 'block';
  exportLocationButton.disabled = true;
}

function showLicenseMessage(text, type) {
  licenseMessage.textContent = text;
  licenseMessage.className = `message ${type}`;
  licenseMessage.style.display = 'block';
}

activateLicenseBtn.addEventListener('click', async () => {
  const code = licenseCodeInput.value.trim();
  if (!code) {
    showLicenseMessage('Please enter a license code', 'error');
    return;
  }

  activateLicenseBtn.disabled = true;
  activateLicenseBtn.innerHTML = '<span>⏳</span><span>Validating...</span>';

  try {
    const result = await window.licenseManager.validateLicense(code);

    if (result.valid) {
      await window.licenseManager.storeLicense(code);
      showLicenseActive(result);
      licenseMessage.style.display = 'none';
    } else {
      showLicenseMessage(result.error || 'Invalid license code', 'error');
    }
  } catch (error) {
    showLicenseMessage('Failed to validate license: ' + error.message, 'error');
  } finally {
    activateLicenseBtn.disabled = false;
    activateLicenseBtn.innerHTML = '<span>🔑</span><span>Activate License</span>';
  }
});

deactivateLicenseBtn.addEventListener('click', async () => {
  await window.licenseManager.clearLicense();
  licenseCodeInput.value = '';
  showLicenseInput();
});

initializeLicense();

/**
 * Asset selection
 */
function updateAssetCountBadge() {
  const allCheckboxes = document.querySelectorAll('.asset-checkbox-item input[type="checkbox"]');
  const checkedCheckboxes = document.querySelectorAll('.asset-checkbox-item input[type="checkbox"]:checked');
  const badge = document.getElementById('assetCountBadge');

  if (badge) {
    if (checkedCheckboxes.length === allCheckboxes.length) {
      badge.textContent = 'All';
    } else if (checkedCheckboxes.length === 0) {
      badge.textContent = 'None';
    } else {
      badge.textContent = `${checkedCheckboxes.length}/${allCheckboxes.length}`;
    }
  }
}

selectAllAssetsButton.addEventListener('click', () => {
  document.querySelectorAll('.asset-checkbox-item input[type="checkbox"]').forEach(cb => cb.checked = true);
  updateAssetCountBadge();
});

deselectAllAssetsButton.addEventListener('click', () => {
  document.querySelectorAll('.asset-checkbox-item input[type="checkbox"]').forEach(cb => cb.checked = false);
  updateAssetCountBadge();
});

document.querySelectorAll('.asset-checkbox-item input[type="checkbox"]').forEach(checkbox => {
  checkbox.addEventListener('change', updateAssetCountBadge);
});

function getSelectedAssets() {
  const checkboxes = document.querySelectorAll('.asset-checkbox-item input[type="checkbox"]:checked');
  const selectedAssets = Array.from(checkboxes).map(checkbox => checkbox.value);
  return selectedAssets.length > 0 ? selectedAssets : null;
}

/**
 * Export location assets
 */
exportLocationButton.addEventListener('click', async () => {
  try {
    if (!canStartExport()) return;

    if (!isLicenseValid) {
      showLocationMessage('Please activate a valid license to export', 'error');
      return;
    }

    const locationId = currentLocationIdInput.value.trim();
    if (!locationId) {
      showLocationMessage('Location ID not detected. Please ensure you are on a GHL page.', 'error');
      return;
    }

    const selectedAssets = getSelectedAssets();
    if (!selectedAssets) {
      showLocationMessage('Please select at least one asset type to export', 'error');
      return;
    }

    const format = exportFormatSelect ? exportFormatSelect.value : 'xlsx';

    // Validate and record license usage
    const licenseCode = await window.licenseManager.getStoredLicense();
    const usageResult = await window.licenseManager.recordUsage(licenseCode, {
      locationId,
      exportType: 'location_assets'
    });

    if (!usageResult.success) {
      showLocationMessage(usageResult.error || 'License validation failed', 'error');
      initializeLicense();
      return;
    }

    console.log('[Popup] Exporting location assets:', locationId, 'format:', format, 'assets:', selectedAssets);

    exportLocationButton.disabled = true;
    showExportOverlay();

    locationProgress.style.display = 'block';
    locationMessageDiv.style.display = 'none';
    locationProgressBar.style.width = '0%';
    locationProgressText.textContent = 'Preparing export...';

    const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    if (!tabs[0]) {
      throw new Error('No active tab found');
    }

    chrome.tabs.sendMessage(tabs[0].id, {
      action: 'exportLocationAssets',
      locationId: locationId,
      format: format,
      selectedAssets: selectedAssets
    }, (response) => {
      if (chrome.runtime.lastError) {
        console.error('[Popup] Location export error:', chrome.runtime.lastError);
        showLocationMessage('Unable to export. Please refresh the GHL page and try again.', 'error');
        resetLocationUI();
        return;
      }

      if (!response || !response.success) {
        showLocationMessage(response?.error || 'Export failed', 'error');
        resetLocationUI();
        return;
      }
    });

  } catch (error) {
    console.error('[Popup] Location export error:', error);
    showLocationMessage(error.message, 'error');
    resetLocationUI();
  }
});

/**
 * Show location message
 */
function showLocationMessage(text, type) {
  locationMessageDiv.textContent = text;
  locationMessageDiv.className = `message ${type}`;
  locationMessageDiv.style.display = 'block';
}

/**
 * Reset location export UI
 */
function resetLocationUI() {
  exportLocationButton.disabled = false;
  hideExportOverlay();
  setTimeout(() => {
    locationProgress.style.display = 'none';
    locationProgressBar.style.width = '0%';
  }, 2000);
}

/**
 * Handle export completion
 */
function handleExportComplete(message) {
  console.log('[Popup] Handling export complete');
  chrome.storage.local.set({ locationExportState: { isExporting: false, progress: 0, message: '' } });
  hideExportOverlay();
  showLocationMessage(message, 'success');
  resetLocationUI();
}

/**
 * Handle export error
 */
function handleExportError(message) {
  console.log('[Popup] Handling export error:', message);
  chrome.storage.local.set({ locationExportState: { isExporting: false, progress: 0, message: '' } });
  hideExportOverlay();
  showLocationMessage(message, 'error');
  resetLocationUI();
}

/**
 * Listen for progress updates
 */
chrome.runtime.onMessage.addListener((request) => {
  try {
    if (request.action === 'locationExportProgress') {
      console.log('[Popup] Location progress received:', request.progress, request.message);

      if (locationProgressText) locationProgressText.textContent = request.message;
      if (locationProgressBar) locationProgressBar.style.width = request.progress + '%';
      updateExportOverlay(request.progress, request.message);

      if (request.progress >= 100) {
        console.log('[Popup] Location export complete, dismissing overlay');
        handleExportComplete('Export completed successfully! Check your downloads folder.');
      } else if (request.progress === 0 && request.message && request.message.startsWith('Error:')) {
        console.log('[Popup] Location export error, dismissing overlay');
        handleExportError(request.message);
      }
    }
  } catch (error) {
    console.error('[Popup] Error in message listener:', error);
  }
});

/**
 * Export monitor (backup mechanism)
 */
let exportCheckInterval = null;

function startExportMonitor() {
  if (exportCheckInterval) return;

  console.log('[Popup] Starting export monitor');
  exportCheckInterval = setInterval(async () => {
    if (!isExportRunning) {
      stopExportMonitor();
      return;
    }

    try {
      const result = await chrome.storage.local.get(['locationExportState']);

      if (result.locationExportState) {
        const state = result.locationExportState;
        if (!state.isExporting && isExportRunning) {
          console.log('[Popup] Monitor detected location export finished');
          if (state.progress >= 100 || state.message === 'Export complete!') {
            handleExportComplete('Export completed successfully! Check your downloads folder.');
          } else if (state.message && state.message.startsWith('Error:')) {
            handleExportError(state.message);
          } else {
            hideExportOverlay();
            resetLocationUI();
          }
          stopExportMonitor();
          return;
        }
      }
    } catch (error) {
      console.error('[Popup] Error in export monitor:', error);
    }
  }, 1000);
}

function stopExportMonitor() {
  if (exportCheckInterval) {
    console.log('[Popup] Stopping export monitor');
    clearInterval(exportCheckInterval);
    exportCheckInterval = null;
  }
}

/**
 * Auto-detect location on popup open
 */
chrome.tabs.query({ active: true, currentWindow: true }, async (tabs) => {
  console.log('[Popup] Initializing, active tab:', tabs[0]?.url);

  if (!tabs[0]) {
    console.error('[Popup] No active tab found');
    return;
  }

  chrome.tabs.sendMessage(tabs[0].id, { action: 'checkGHLPage' }, (response) => {
    if (chrome.runtime.lastError) {
      console.error('[Popup] GHL check error:', chrome.runtime.lastError);
      currentLocationIdInput.value = '';
      currentLocationIdInput.placeholder = 'Extension not loaded. Please refresh the page.';
      return;
    }

    console.log('[Popup] GHL page check result:', response);

    if (!response || !response.isGHLPage) {
      console.warn('[Popup] Not on a GHL page');
      currentLocationIdInput.value = '';
      currentLocationIdInput.placeholder = 'Not a GHL page';
      return;
    }

    if (response.locationId) {
      currentLocationIdInput.value = response.locationId;
      console.log('[Popup] Location ID set:', response.locationId);
    }
  });
});
